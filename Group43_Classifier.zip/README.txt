How to run:
  Doubleclick Classifier.jar

How to use the GUI:
  Filling the dataset:
    1. Add one or multiple files using the "Browse" button.
    2. Type the corresponding classname in the "Class" textfield.
    3. Click "add file to documentstore".
  Estimating a class:
    1. Add the file which needs to be estimated using the "Browse" button.
    2. Optional: Change the slider values. (Note: keep the minOccurrences slider low when training with few documents for obvious reasons).
    3. Press the "Estimate" button.
    4. Enter the correct class in screen that pops up.
    5. Press the "Ok" button if you want to add the file to the document store, press "Cancel" to not add the file to the store.
  Slider Usage:
    1. Percentage of Condprobs: This is the percentage of Conditional probabilities to be used for calculation.
    2. Smoothing: This is the smoothing variable as indicated the reader.
    3. Min Occurrences: This is the minimum amount of times a word has to be in the bag for it to be used in calculation.

System requirements:
  Works on: windows 8 and 10
  Should work on: anything capable of running java8

